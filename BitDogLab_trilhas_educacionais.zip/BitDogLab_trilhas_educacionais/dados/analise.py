# -*- coding: utf-8 -*-
"""Refaz, a partir dos arquivos CSV desta pasta, os números dos testes de conhecimento
e dos questionários de percepção apresentados na dissertação.

Uso:  python analise.py

Só usa a biblioteca padrão do Python 3. Lê testes_conhecimento.csv e percepcao.csv,
mostra um resumo na tela e grava resultados_testes.csv e resultados_percepcao.csv.

Definições (as mesmas do Capítulo 6 da dissertação):
  - média e desvio-padrão das notas de 1 a 5, a partir das contagens por nota
  - teste U de Mann-Whitney bilateral entre as aplicações anterior e posterior, com
    aproximação normal, correção para empates e correção de continuidade
  - tamanho de efeito: correlação bisserial de postos, r = 2U/(n_a n_d) - 1
  - ajustes para comparações múltiplas: Benjamini-Hochberg e Holm-Bonferroni
  - variação relativa da média: 100 (depois - antes) / antes
  - ganho normalizado: (depois - antes) / (5 - antes)
"""
import csv
import math
import os

PASTA = os.path.dirname(os.path.abspath(__file__))
NOTAS = [1, 2, 3, 4, 5]


def ler(nome):
    with open(os.path.join(PASTA, nome), encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def gravar(nome, colunas, linhas):
    with open(os.path.join(PASTA, nome), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(colunas)
        for l in linhas:
            w.writerow([f"{l[c]:.4f}" if isinstance(l[c], float) else l[c] for c in colunas])


def media_dp(cont):
    n = sum(cont)
    m = sum(v * c for v, c in zip(NOTAS, cont)) / n
    dp = math.sqrt(sum(c * (v - m) ** 2 for v, c in zip(NOTAS, cont)) / n)
    return m, dp


def mediana(cont):
    x = [v for v, c in zip(NOTAS, cont) for _ in range(c)]
    n = len(x)
    return x[n // 2] if n % 2 else (x[n // 2 - 1] + x[n // 2]) / 2


def mann_whitney(antes, depois):
    """U das notas posteriores em relação às anteriores e p-valor bilateral."""
    na, nd = sum(antes), sum(depois)
    n = na + nd
    # posto médio de cada nota na amostra reunida
    soma_postos_depois, empates, anterior = 0.0, 0.0, 0
    for a, d in zip(antes, depois):
        t = a + d
        if t:
            posto = anterior + (t + 1) / 2
            soma_postos_depois += d * posto
            empates += t ** 3 - t
            anterior += t
    u = soma_postos_depois - nd * (nd + 1) / 2
    mu = na * nd / 2
    sigma = math.sqrt(na * nd / 12 * ((n + 1) - empates / (n * (n - 1))))
    if sigma == 0:
        return u, 1.0
    z = max(abs(u - mu) - 0.5, 0.0) / sigma
    p = math.erfc(z / math.sqrt(2))          # 2 [1 - Phi(z)]
    return u, p


def benjamini_hochberg(ps):
    m = len(ps)
    ordem = sorted(range(m), key=lambda i: ps[i])
    aj, menor = [0.0] * m, 1.0
    for pos in range(m - 1, -1, -1):
        i = ordem[pos]
        menor = min(menor, ps[i] * m / (pos + 1))
        aj[i] = menor
    return aj


def holm_bonferroni(ps):
    m = len(ps)
    ordem = sorted(range(m), key=lambda i: ps[i])
    aj, maior = [0.0] * m, 0.0
    for pos, i in enumerate(ordem):
        maior = max(maior, (m - pos) * ps[i])
        aj[i] = min(1.0, maior)
    return aj


def pearson(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    return sxy / math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))


def br(x, nd=2, sinal=False):
    return (f"{x:+.{nd}f}" if sinal else f"{x:.{nd}f}").replace('.', ',')


# ---------------------------------------------------------------- testes de conhecimento
dados, ordem = {}, []
for l in ler('testes_conhecimento.csv'):
    chave = (l['trilha'], l['item'])
    if chave not in dados:
        dados[chave] = {}
        ordem.append(chave)
    dados[chave][l['aplicacao']] = [int(l[f'nota_{k}']) for k in NOTAS]

res = []
for trilha, item in ordem:
    antes, depois = dados[(trilha, item)]['anterior'], dados[(trilha, item)]['posterior']
    m1, s1 = media_dp(antes)
    m2, s2 = media_dp(depois)
    u, p = mann_whitney(antes, depois)
    res.append({
        'trilha': trilha, 'item': item,
        'media_anterior': m1, 'dp_anterior': s1, 'media_posterior': m2, 'dp_posterior': s2,
        'mediana_anterior': float(mediana(antes)), 'mediana_posterior': float(mediana(depois)),
        'variacao_relativa_pct': 100 * (m2 - m1) / m1,
        'ganho_normalizado': (m2 - m1) / (5 - m1),
        'U': u, 'r': 2 * u / (sum(antes) * sum(depois)) - 1, 'p': p,
    })
ps = [l['p'] for l in res]
for l, bh, hb in zip(res, benjamini_hochberg(ps), holm_bonferroni(ps)):
    l['p_BH'], l['p_HB'] = bh, hb

gravar('resultados_testes.csv',
       ['trilha', 'item', 'media_anterior', 'dp_anterior', 'media_posterior', 'dp_posterior',
        'mediana_anterior', 'mediana_posterior', 'variacao_relativa_pct', 'ganho_normalizado',
        'U', 'r', 'p', 'p_BH', 'p_HB'], res)

print('TESTES DE CONHECIMENTO')
print(f"{'':58s}  antes depois  var.%   <g>    U     r      p   p_BH   p_HB")
atual = None
for l in res:
    if l['trilha'] != atual:
        atual = l['trilha']
        print(atual)
    print(f"  {l['item'][:56]:56s}  {br(l['media_anterior'])}  {br(l['media_posterior'])}"
          f"  {br(l['variacao_relativa_pct'], 1, True):>6s}  {br(l['ganho_normalizado'])}  {br(l['U'], 1):>5s}"
          f"  {br(l['r'])}  {br(l['p'], 3)}  {br(l['p_BH'], 3)}  {br(l['p_HB'], 3)}")

print('\nSÍNTESE POR TRILHA (itens com valor menor que 0,05)')
print(f"  {'':18s} itens    p  p_BH  p_HB  <g> médio")
trilhas = []
for l in res:
    if l['trilha'] not in trilhas:
        trilhas.append(l['trilha'])
for t in trilhas + ['Total']:
    sub = [l for l in res if t == 'Total' or l['trilha'] == t]
    g_medio = '' if t == 'Total' else br(sum(l['ganho_normalizado'] for l in sub) / len(sub))
    print(f"  {t:18s} {len(sub):5d} {sum(l['p'] < 0.05 for l in sub):4d}"
          f" {sum(l['p_BH'] < 0.05 for l in sub):5d} {sum(l['p_HB'] < 0.05 for l in sub):5d}  {g_medio}")

print('\nCONHECIMENTO PRÉVIO E GANHO (26 itens)')
antes = [l['media_anterior'] for l in res]
depois = [l['media_posterior'] for l in res]
medidas = [('variação relativa', [l['variacao_relativa_pct'] for l in res]),
           ('ganho em pontos', [d - a for a, d in zip(antes, depois)]),
           ('ganho normalizado', [l['ganho_normalizado'] for l in res])]
for nome, y in medidas:
    print(f"  correlação de Pearson entre a média anterior e {nome}: {br(pearson(antes, y), 2, True)}")
# reta de mínimos quadrados da variação relativa em função da média anterior
x, y = antes, medidas[0][1]
mx, my = sum(x) / len(x), sum(y) / len(y)
incl = sum((a - mx) * (b - my) for a, b in zip(x, y)) / sum((a - mx) ** 2 for a in x)
print(f"  reta ajustada: variação relativa = {br(my - incl * mx, 1)} {br(incl, 1, True)} x média anterior")
for rotulo, grupo in [('média anterior < 2,5 ', [l for l in res if l['media_anterior'] < 2.5]),
                      ('média anterior >= 2,5', [l for l in res if l['media_anterior'] >= 2.5])]:
    k = len(grupo)
    print(f"  {rotulo}: {k} itens, ganho em pontos {br(sum(l['media_posterior'] - l['media_anterior'] for l in grupo) / k)},"
          f" média posterior {br(sum(l['media_posterior'] for l in grupo) / k)},"
          f" <g> médio {br(sum(l['ganho_normalizado'] for l in grupo) / k)}")

# ---------------------------------------------------------------- percepção
perc = []
for l in ler('percepcao.csv'):
    cont = [int(l[f'resposta_{k}']) for k in NOTAS]
    m, s = media_dp(cont)
    perc.append({'trilha': l['trilha'], 'indicador': l['indicador'], 'media': m, 'dp': s})
gravar('resultados_percepcao.csv', ['trilha', 'indicador', 'media', 'dp'], perc)

print('\nPERCEPÇÃO (média e desvio-padrão, escala de 1 a 5)')
atual = None
for l in perc:
    if l['trilha'] != atual:
        atual = l['trilha']
        print(atual)
    print(f"  {l['indicador'][:74]:74s}  {br(l['media'])} ({br(l['dp'])})")

print('\nArquivos gravados: resultados_testes.csv e resultados_percepcao.csv')
