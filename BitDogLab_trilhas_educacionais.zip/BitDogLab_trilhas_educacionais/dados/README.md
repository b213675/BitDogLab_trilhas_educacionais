# Dados das oficinas

Respostas dos 18 estudantes que participaram das cinco trilhas em uma escola pública
de Campinas (SP). Os instrumentos foram respondidos sem identificação, e os arquivos
trazem apenas contagens: quantos estudantes ficaram em cada nota ou em cada ponto da
escala. Não há dados individuais.

Os arquivos são CSV em UTF-8, separados por vírgula, com ponto como separador
decimal. O GitHub mostra cada um como tabela. No Excel, use Dados > De Texto/CSV.

## Arquivos de dados

### `testes_conhecimento.csv`

Testes de conhecimento aplicados antes e depois das oficinas, com 26 itens.

| Coluna | Significado |
|---|---|
| `trilha` | Energia solar, Energia eólica, Teste integrador, Maquete ou PixelArt |
| `item` | Conteúdo avaliado |
| `aplicacao` | `anterior` (antes da oficina) ou `posterior` (depois) |
| `nota_1` a `nota_5` | Número de estudantes com cada nota, de 1 (menos acertos) a 5 (mais acertos) |
| `n` | Total de respostas |

O teste integrador reúne três questões sobre grandezas elétricas, comuns às trilhas
solar e eólica. Nessas duas trilhas, a aplicação anterior foi feita antes da oficina
solar, e a posterior, depois da eólica. A trilha de programação com inteligência
artificial não teve teste de conhecimento.

### `percepcao.csv`

Questionários de percepção respondidos ao fim de cada trilha, em escala Likert de
cinco pontos.

| Coluna | Significado |
|---|---|
| `trilha` | Energia solar, Energia eólica, Maquete, PixelArt ou Programação com IA |
| `indicador` | Afirmação avaliada |
| `resposta_1` a `resposta_5` | Número de estudantes em cada ponto da escala, de 1 (mais negativa) a 5 (mais positiva) |
| `n` | Total de respostas |

### `percepcao_cotuca.csv`

Percepção de 29 estudantes do Colégio Técnico de Campinas (COTUCA) sobre a mesma
atividade de programação com inteligência artificial, usada na dissertação como
comparação. As contagens vêm da distribuição de frequências publicada em:

PINTO, J. S.; GRAEL, B. S.; MENEZES, F.; FRUETT, F. Ensino de sistemas embarcados com
geração de código por linguagem natural em plataforma web: uma aplicação com a
BitDogLab. In: CONGRESSO BRASILEIRO DE EDUCAÇÃO EM ENGENHARIA, 54., 2026, Belo
Horizonte. *Anais* [...]. Brasília: ABENGE, 2026.

### `idades.csv`

Número de participantes por idade, de 11 a 15 anos.

## Análise

`analise.py` lê os arquivos acima e refaz os números da dissertação. Ele usa só a
biblioteca padrão do Python 3:

```
python analise.py
```

O programa mostra um resumo na tela e grava dois arquivos.

### `resultados_testes.csv`

| Coluna | Significado |
|---|---|
| `media_anterior`, `dp_anterior` | Média e desvio-padrão das notas antes da oficina |
| `media_posterior`, `dp_posterior` | Média e desvio-padrão das notas depois da oficina |
| `mediana_anterior`, `mediana_posterior` | Medianas |
| `variacao_relativa_pct` | 100 x (média posterior - média anterior) / média anterior |
| `ganho_normalizado` | (média posterior - média anterior) / (5 - média anterior) |
| `U` | Estatística do teste de Mann-Whitney das notas posteriores em relação às anteriores |
| `r` | Tamanho de efeito, correlação bisserial de postos: 2U / (18 x 18) - 1 |
| `p` | p-valor bilateral, com aproximação normal, correção para empates e correção de continuidade |
| `p_BH` | p-valor ajustado pelo procedimento de Benjamini-Hochberg, para as 26 comparações |
| `p_HB` | p-valor ajustado pelo procedimento de Holm-Bonferroni, para as 26 comparações |

### `resultados_percepcao.csv`

Média e desvio-padrão de cada indicador de percepção, por trilha.

## Limites dos dados

As respostas são anônimas e não foram pareadas, de modo que as aplicações anterior e
posterior são tratadas como amostras independentes. O estudo não teve grupo de
controle, e os resultados vêm de um único grupo de uma única escola. A discussão
completa está no capítulo de metodologia da dissertação.
